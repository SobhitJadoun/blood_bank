<?php
	// include('connection.php');
	session_start();
	session_unset();
	session_unset();
	header('location:../index.php');
// 	session_start();
// session_unset();
// session_destroy();

// header("location:../index.php");
exit();
	?>