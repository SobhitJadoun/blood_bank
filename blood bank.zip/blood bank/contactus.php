<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Contact us</title>
        <!-- =============font awesome=============== -->
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
            integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
        <!-- Latest compiled and minified CSS -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
            rel="stylesheet">

            <link rel="stylesheet" href="css/main.css">
        <script
            src="https://code.jquery.com/jquery-3.3.1.js"
            integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
            crossorigin="anonymous">
</script>
  
    </head>
    <body>
    <div class="container-fluid top-header">
    <div class="row">
        <div class="col-sm-6 col-md-3  p-3 bg-dark text-white top-info">
            <i class="fa-solid fa-phone icon"></i>
            <p class="phone">| +91-9068605920</p>
        </div>
        <div class="col-sm-6 col-md-3 p-3 bg-dark text-white top-info">
            <i class="fa-solid fa-envelope icon"></i>
            <p class="phone">| sobhitjadoun@gmail.com</p>
        </div>
        <div class="col-sm-6 col-md-3 p-3 bg-dark text-white top-info">
            <i class="fa-solid fa-location-dot"></i>
            <p class="phone">| Chandigarh, Punjab</p>
        </div>
        <div class="col-sm-6 col-md-3 p-3 bg-danger text-white top-info">
            <p class="follow ">Follow Now </p>
            <a href=""><i class="fa-brands fa-facebook f-icon" ></i></a>
            <a href=""><i class="fa-brands fa-square-twitter f-icon"></i></a>
            <a href=""><i class="fa-brands fa-instagram f-icon"></i></a>

        </div>
      </div>
</div>
<!-- ==================top header end====================== -->
<!-- =============main Header===================== -->
<nav class="navbar navbar-expand-sm navbar-light">
        <div class="container-fluid">
            <a href="" class="navbar-brand"><img src="img/logo.png" alt=""></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav m-auto">
              <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              <a class="nav-link" href="aboutus.php">About Us</a>
              <a class="nav-link" href="#">campaign</a>
              <a class="nav-link" href="contactus.php">Contact Us</a>
              <a class="nav-link" href="dashboard/dashboard.php">SignUp/SignIn</a>
            </div>
          </div>
        </div>
      </nav>
        
        <div class="container">
            <div class="row contact-us">
                <div class="col-12 col-md-6 col-xl-6 left">
                        <img src="img/contact.jpg" alt="">
                </div>
                <div class="col-12 col-md-6">
                   <div class="contact-main">
                    <p>Let Connect with Us</p>
                    <form action="" method="post" class="contact-form">
                        <div class="mb-3 mt-3">
                          <label for="email" class="text-white fs-5">Email:</label>
                          <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                        </div>
                        <div class="mb-3">
                          <label for="name" class="text-white fs-5">Name:</label>
                          <input type="text" class="form-control" id="name" placeholder="Enter Name" name="Name">
                        </div>
                        <div class="mb-3">
                          <label for="contact" class="text-white fs-5">Contact:</label>
                          <input type="contact" class="form-control" id="contact" placeholder="Enter Contact" name="contact">
                        </div>
                        <div class="mb-3">
                          <label for="Description" class="text-white fs-5">Description:</label>
                          <textarea class="form-control" rows="4" id="comment" name="text"></textarea>
                        </div>
                        <div class="form-check mb-3">
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                      </form>
                   </div>

                </div>
            </div>
        </div>

        <!-- =========footer section start============ -->
        <div class="container-fluid ftr" id="footer">
            <div class="row ft">
                <div class="col-12 col-sm-6 col-md-3 first">
                    <img src="img/logo.jpg" alt="">
                    <h1>Donate Blood and Take Real Blessing</h1>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <h1>About us</h1>
                    <p> accusantium veniam mollitia enim perferendis, repellendus fugiat porro assumenda rerum nihil voluptas tempora, reiciendis accusamus incidunt! Labore, fugit!</p>
                    <span>Phone:- +91-9068605920</span><br>
                    <span>Email-: shobhtisthakur105@gmail.com</span>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <h1>Quick Link</h1>
                    <ul>
                        <li><span>>></span><a href="">Service</a></li>
                        <li><span>>></span><a href="">About Us</a></li>
                        <li><span>>></span><a href="">New Campagin</a></li>
                        <li><span>>></span><a href="">Contact</a></li>
                    </ul>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <h1>service</h1>
                    <ul>
                        <li><span>>></span><a href="">Blood Donation</a></li>
                        <li><span>>></span><a href="">Health Check</a></li>
                        <li><span>>></span><a href="">Blood Bank</a></li>
                        <li><span>>></span><a href="">Donation Process</a></li>
                        <li><span>>></span><a href="">Blood Info</a></li>
                    </ul>
                </div>
            </div>
            <div class="btm-ft text-center">
                <p>Copyright 2023 Sobhit Jadoun, All Right Reserved</p>
            </div>
        </div>


<!-- ===============footer section end================
 -->
        </body>
        </html>