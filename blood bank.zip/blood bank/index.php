<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- =============font awesome=============== -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Latest compiled and minified CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <title>Blood Camp</title>
        <link rel="stylesheet" href="css/main.css">
        <script
            src="https://code.jquery.com/jquery-3.3.1.js"
            integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
            crossorigin="anonymous">
</script>
     
    </head>
    <body>
    <div class="container-fluid top-header">
    <div class="row">
        <div class="col-sm-6 col-md-3  p-3 bg-dark text-white top-info">
            <i class="fa-solid fa-phone icon"></i>
            <p class="phone">| +91-9068605920</p>
        </div>
        <div class="col-sm-6 col-md-3 p-3 bg-dark text-white top-info">
            <i class="fa-solid fa-envelope icon"></i>
            <p class="phone">| sobhitjadoun@gmail.com</p>
        </div>
        <div class="col-sm-6 col-md-3 p-3 bg-dark text-white top-info">
            <i class="fa-solid fa-location-dot"></i>
            <p class="phone">| Chandigarh, Punjab</p>
        </div>
        <div class="col-sm-6 col-md-3 p-3 bg-danger text-white top-info">
            <p class="follow ">Follow Now </p>
            <a href=""><i class="fa-brands fa-facebook f-icon" ></i></a>
            <a href=""><i class="fa-brands fa-square-twitter f-icon"></i></a>
            <a href=""><i class="fa-brands fa-instagram f-icon"></i></a>

        </div>
      </div>
</div>
<!-- ==================top header end====================== -->
<!-- =============main Header===================== -->
<nav class="navbar navbar-expand-sm navbar-light">
        <div class="container-fluid">
            <a href="" class="navbar-brand"><img src="img/logo.png" alt=""></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav m-auto">
              <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              <a class="nav-link" href="aboutus.php">About Us</a>
              <a class="nav-link" href="#">campaign</a>
              <a class="nav-link" href="contactus.php">Contact Us</a>
              <a class="nav-link" href="dashboard/dashboard.php">SignUp/SignIn</a>
            </div>
          </div>
        </div>
      </nav>


        <!-- ===============================hero section======================== -->
        <!-- Carousel -->
        <div id="demo" class="carousel slide" data-bs-ride="carousel">

            <!-- Indicators/dots -->
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#demo"
                    data-bs-slide-to="0" class="active"></button>
                <button type="button" data-bs-target="#demo"
                    data-bs-slide-to="1"></button>
                <button type="button" data-bs-target="#demo"
                    data-bs-slide-to="2"></button>
            </div>

            <!-- The slideshow/carousel -->
            <div class="carousel-inner set">
                <div class="carousel-item active">
                    <img src="img/1.jpg" alt="Los Angeles" class="d-block"
                        style="width:100%">
                    <div class="carousel-caption">
                        <h3>Donate Blood and Inspire Others</h3>
                        <p>Donate blood and save life.</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/2.jpg" alt="Chicago" class="d-block"
                        style="width:100%">
                    <div class="carousel-caption">
                        <h3>Donate Blood and Save Life!</h3>
                        <p>Your Blood can bring smile in Other Person Face</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/blood.jpg" alt="New York" class="d-block"
                        style="width:100%">
                    <div class="carousel-caption">
                        <h3>Don't be “A negative”;<br> be “O positive”.</h3>
                        <p> “O people”, did you know you are the Universal Donors.</p>
                       
                    </div>
                </div>
            </div>

            <!-- Left and right controls/icons -->
            <button class="carousel-control-prev" type="button"
                data-bs-target="#demo" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button"
                data-bs-target="#demo" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
            </button>
        </div>
<!-- ===========================donate register now========= -->
<div class="container banner">
    <div class="row">
        <div class="col-12 col-md-6 first">
            <a href="donate.html"><h1>Donate Now</h1>
            <p>"Blood Donation Is A Small Act Of Kindness That Does Great And Big Wonders.”</p>
        </a></div>
        <div class="col-12 col-md-6 second">
            <a href="receipt.html"><h1>Receipt Now</h1>
            <p>"Blood Donation Is A Small Act Of Kindness That Does Great And Big Wonders.”</p>
       </a> </div>
    </div>
</div>
<!-- =====================card start========================== -->
<div class="container card" id="card">
            <div class="row">
                <div class="col-12 col-md-4 col-xl-4 card-hover">
                    <div class="flip-card card-own">
                        <div class="flip-card-inner">
                            <div class="flip-card-front">
                                <img src="img/3.jpg" alt="Avatar"
                                    style="width:300px;height:300px;">
                            </div>
                            <div class="flip-card-back">
                                <h1>Becomes a Donor</h1>
                                <p>Be at least 17 years old in most states (16 years old with parental consent in some states).</p>
                               
                            </div>
                        </div>
                        <div class="card-img">
                            <img src="img/first-aid.png" alt="">
                        </div>
                    </div>
                    <div class="card-info">
                        <h1>Becomes a Donor</h1>
                        <p>Be at least 17 years old in most states (16 years old with parental consent in some states). Weigh at least 110 pounds. Additional weight requirements apply for donors 18 years old and younger and all high school donors. Have not donated blood in the last 56 days.</p>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-xl-4 card-hover">
                    <div class="flip-card card-own">
                        <div class="flip-card-inner">
                            <div class="flip-card-front">
                                <img src="img/6.jpg" alt="Avatar"
                                    style="width:300px;height:300px;">
                            </div>
                            <div class="flip-card-back">
                                <h1>Why we gives Blood?</h1>
                                <p>Blood is essential to help patients survive surgeries, cancer treatment, chronic illnesses, and traumatic injuries. This lifesaving care starts with one person making a generous donation. The need for blood is constant. But only about 3% of age-eligible people donate blood yearly.</p>
                                
                            </div>
                        </div>
                        <div class="card-img">
                            <img src="img/heart.png" alt="">
                        </div>
                    </div>
                    <div class="card-info">
                        <h1>Why Give Blood?</h1>
                        <p>Safe blood saves lives. Blood is needed by women with complications during pregnancy and childbirth, children with severe anaemia, often resulting from malaria or malnutrition, accident victims and surgical and cancer patients.</p>
                    </div>
                </div>
                <div class="col-12 col-md-4 col-xl-4 card-hover">
                    <div class="flip-card card-own">
                        <div class="flip-card-inner">
                            <div class="flip-card-front">
                                <img src="img/4.jpg" alt="Avatar"
                                    style="width:300px;height:300px;">
                            </div>
                            <div class="flip-card-back">
                                <h1>How Donations Helps</h1>
                                <p> Donated blood must be very closely matched to the donor’s blood type to avoid transfusion-related complications. Since most patients with sickle cell disease are Black or African American.</p>
                               
                            </div>
                        </div>
                        <div class="card-img">
                            <img src="img/tube.png" alt="">
                        </div>
                    </div>
                    <div class="card-info">
                        <h1>How Donations Helps</h1>
                        <p>Every day, blood donors help patients of all ages: accident and burn victims, heart surgery and organ transplant patients, and those battling cancer. In fact, every two seconds, someone in the U.S. needs blood.</p>
                    </div>
                </div>
               

            </div>
        </div>

<!-- ========================card end =================== -->

<!-- =============about section================= -->
<div class="container abt" id="about">
            <h1>About Us</h1>
            <hr>
        </div>
        <div class="cotainer abt-sec">
            <div class="row">
                <div class="col-12 col-sm-6">
                    <h3>Help the People In need</h3>
                    <h1>Welcome to Blood Donor Organization</h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam maiores atque earum ut, impedit placeat. Officiis cumque, laboriosam facere ratione harum vero labore maiores qui nisi explicabo, minus numquam quos!</p>
                    <div class="row point">
                        <div class="col-6 col-sm-6">
                            <span>>></span>
                            <p>Good Service</p><br>
                            <span>>></span>
                            <p>Help People</p><br>
                            <span>>></span>
                            <p>Hyging Tool</p><br>
                        </div>
                        <div class="col-6 col-sm-6">
                            <span>>></span>
                            <p>24X7 Help Support</p><br>
                            <span>>></span>
                            <p>Helth Check</p><br>
                            <span>>></span>
                            <p>Blood Bnak</p><br>
                        </div>
                    </div>
                    <button class="btn" id="#" name="explore more">Explore More</button>
                </div>
                <div class="col-12 col-sm-6">
                    <img src="img/about.jpg" alt="">
                </div>
            </div>
        </div>
<!-- =======about section end========= -->

<!-- ==================service section ============== -->
<div class="container service">
    <div class="sr-title">
        <h1>Services</h1>
    </div>
    <div class="row">
        <div class="col-12 col-md-3">
            <img src="img/blood-collection-g206bdd83e_640.jpg" alt="">
            <h1>Blood Collection</h1>
            <button class="btn" type="button " name="Enquiry">Enquiry Now</button>
        </div>
        <div class="col-12 col-md-3">
            <img src="img/blood-donation.jpg" alt="">
            <h1>Blood Bank</h1>
            <button class="btn" type="button " name="Enquiry">Enquiry Now</button>
        </div>
        <div class="col-12 col-md-3">
            <img src="img/Blood.png" alt="">
            <h1>Provision Of Blood Cells</h1>
            <button class="btn" type="button " name="Enquiry">Enquiry Now</button>
        </div>
        <div class="col-12 col-md-3">
            <img src="img/platletes.png" alt="">
            <h1>Provision Of Plaletes</h1>
            <button class="btn" type="button " name="Enquiry">Enquiry Now</button>
        </div>
    </div>
</div>


<!-- =========================service section end================== -->
<div class="container-fluid gradient-background" id="counter">
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-sm-6">
          <div class="counter " id="count">
            <div class="counter-content">
              <div class="counter-icon">
            <img src="img/experience.png" alt="">

              </div>
              <h3> Year's Experience </h3>
            </div>
            <span class="counter-value"> 5 </span>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="counter green">
            <div class="counter-content">
              <div class="counter-icon">
                <img src="img/donors.png" alt="">
              </div>
              <h3> Happy Donors </h3>
            </div>
            <span class="counter-value"> 2854 </span>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="counter gree">
            <div class="counter-content">
              <div class="counter-icon">
                <img src="img/awards.png" alt="">
              </div>
              <h3> Total Awards </h3>
            </div>
            <span class="counter-value"> 54 </span>
          </div>
        </div>
        <div class="col-md-3 col-sm-6">
          <div class="counter gray">
            <div class="counter-content">
              <div class="counter-icon">
               <img src="img/recipient.png" alt="">
              </div>
              <h3> Happy Receipents </h3>
            </div>
            <span class="counter-value"> 1585 </span>
          </div>
        </div>
      </div>
    </div> </div>
<!-- ==================banner===================== -->
<div class="container-fluid ban">
    <div class="row">
        <div class="col-12 col-sm-8 col-md-8 left">
            <h1>Let's Change the World, Join Us Now!</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, praesentium. Quod possimus cupiditate ea doloribus delectus quae animi vel et, fugit suscipit fugiat numquam fuga? Aliquid, placeat. Atque, eius neque.</p>
        </div>
        <div class="col-12 col-sm-4 col-md-4 right">
            <button class="btn" id="btn">Contact Us</button>
        </div>
    </div>
</div>
<!-- =========footer section start============ -->
<div class="container-fluid ftr" id="footer">
            <div class="row ft">
                <div class="col-12 col-sm-6 col-md-3 first">
                    <img src="img/logo.jpg" alt="">
                    <h1>Donate Blood and Take Real Blessing</h1>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <h1>About us</h1>
                    <p> accusantium veniam mollitia enim perferendis, repellendus fugiat porro assumenda rerum nihil voluptas tempora, reiciendis accusamus incidunt! Labore, fugit!</p>
                    <span>Phone:- +91-9068605920</span><br>
                    <span>Email-: shobhtisthakur105@gmail.com</span>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <h1>Quick Link</h1>
                    <ul>
                        <li><span>>></span><a href="">Service</a></li>
                        <li><span>>></span><a href="">About Us</a></li>
                        <li><span>>></span><a href="">New Campagin</a></li>
                        <li><span>>></span><a href="">Contact</a></li>
                    </ul>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <h1>service</h1>
                    <ul>
                        <li><span>>></span><a href="">Blood Donation</a></li>
                        <li><span>>></span><a href="">Health Check</a></li>
                        <li><span>>></span><a href="">Blood Bank</a></li>
                        <li><span>>></span><a href="">Donation Process</a></li>
                        <li><span>>></span><a href="">Blood Info</a></li>
                    </ul>
                </div>
            </div>
            <div class="btm-ft text-center">
                <p>Copyright 2023 Sobhit Jadoun, All Right Reserved</p>
            </div>
        </div>

<!-- ===============footer section end================
 -->

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
            crossorigin="anonymous"></script>
    </body>
</html>