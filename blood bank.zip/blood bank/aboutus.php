<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
        integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>About Us</title>
    <link rel="stylesheet" href="css/main.css">
    <script src="https://code.jquery.com/jquery-3.3.1.js"
        integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous">
        </script>
</head>

<body>
<div class="container-fluid top-header">
    <div class="row">
        <div class="col-sm-6 col-md-3  p-3 bg-dark text-white top-info">
            <i class="fa-solid fa-phone icon"></i>
            <p class="phone">| +91-9068605920</p>
        </div>
        <div class="col-sm-6 col-md-3 p-3 bg-dark text-white top-info">
            <i class="fa-solid fa-envelope icon"></i>
            <p class="phone">| sobhitjadoun@gmail.com</p>
        </div>
        <div class="col-sm-6 col-md-3 p-3 bg-dark text-white top-info">
            <i class="fa-solid fa-location-dot"></i>
            <p class="phone">| Chandigarh, Punjab</p>
        </div>
        <div class="col-sm-6 col-md-3 p-3 bg-danger text-white top-info">
            <p class="follow ">Follow Now </p>
            <a href=""><i class="fa-brands fa-facebook f-icon" ></i></a>
            <a href=""><i class="fa-brands fa-square-twitter f-icon"></i></a>
            <a href=""><i class="fa-brands fa-instagram f-icon"></i></a>

        </div>
      </div>
</div>
<!-- ==================top header end====================== -->
<!-- =============main Header===================== -->
<nav class="navbar navbar-expand-sm navbar-light">
        <div class="container-fluid">
            <a href="" class="navbar-brand"><img src="img/logo.png" alt=""></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav m-auto">
              <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              <a class="nav-link" href="aboutus.php">About Us</a>
              <a class="nav-link" href="#">campaign</a>
              <a class="nav-link" href="contactus.php">Contact Us</a>
              <a class="nav-link" href="dashboard/dashboard.php">SignUp/SignIn</a>
            </div>
          </div>
        </div>
      </nav>


    <!-- =================main section============== -->
    <div class="container-fluid about-title">
    </div>
    <div class="container a-title">
        <h2>OUR VOLUNTEERS</h2>
    </div>
    <div class="para">
        <p>The volunteers who give their time and talents help to fulfill our mission.</p>
    </div>
    <div class="container team">
        <div class="row">
            <div class="col-12 col-md-4 col-xl-4 member">
                
                    <img src="img/testimonial/team_6.jpg" alt="">
                    <h2 class="text-center">Anamika</h2>
                    <p class="text-center text-secondary font-weight-light">founder</p>
                    <div class="social-icon">
                        <div class="col-12 icon">
                            <i class="fa-brands fa-facebook-f" style="color: #e4111c;"></i>
                            <i class="fa-brands fa-twitter" style="color: #e70d0d;"></i>
                            <i class="fa-brands fa-google-plus-g" style="color: #e50b0b;"></i>
                            <i class="fa-brands fa-linkedin-in" style="color: #e70808;"></i>
                        </div>
                   
                </div>
            </div>
            <div class="col-12 col-md-4 col-xl-4 member">
                
                    <img src="img/testimonial/team_7.jpg" alt="">
                    <h2 class="text-center">Sobhit Jadoun</h2>
                    <p class="text-center text-secondary font-weight-light">founder</p>
                    <div class="social-icon">
                        <div class="col-12 icon">
                            <i class="fa-brands fa-facebook-f" style="color: #e4111c;"></i>
                            <i class="fa-brands fa-twitter" style="color: #e70d0d;"></i>
                            <i class="fa-brands fa-google-plus-g" style="color: #e50b0b;"></i>
                            <i class="fa-brands fa-linkedin-in" style="color: #e70808;"></i>
                        </div>
                </div>
            </div>
            <div class="col-12 col-md-4 col-xl-4 member">

                <img src="img/testimonial/team_9.jpg" alt="">
                <h2 class="text-center">Tausif</h2>
                <p class="text-center text-secondary font-weight-light">founder</p>
                <div class="social-icon ">
                    <div class="col-12 icon">
                        <i class="fa-brands fa-facebook-f" style="color: #e4111c;"></i>
                        <i class="fa-brands fa-twitter" style="color: #e70d0d;"></i>
                        <i class="fa-brands fa-google-plus-g" style="color: #e50b0b;"></i>
                        <i class="fa-brands fa-linkedin-in" style="color: #e70808;"></i>
                    </div>
                </div>

            </div>
        </div>
    </div>

<div class="container-fluid a-counter">
    <div class="container a-card">
        <div class="row">
            <div class="col-12 col-md-6 col-xl-3">
                <div class="card">
                    <i class="fa-solid fa-heart-pulse" style="color: #999b9f;"></i>
                    <h2 class="counter-count">125</h2>
                    <p>SUCCESS SMILE</p>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="card">
                    <i class="fa-solid fa-stethoscope" style="color: #8c8c8c;"></i>                    <h2 class="counter-count">725</h2>
                    <p>HAPPY DONOR</p>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="card">
                    <i class="fa-solid fa-users" style="color: #5e6064;"></i>
                    <h2 class="counter-count">613</h2>
                    <p>HAPPY RECIEPENT</p>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="card">
                    <i class="fa-solid fa-award" style="color: #737373;"></i>
                    <h2 class="counter-count">525</h2>
                    <p>TOTAL AWARDS</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- slider======================= -->
<div class="container-fluid a-info text ">
    <div class="row">
        <div class="col-12 col-md-3 col-xl-3 left text-center ">
            <p class="p-3">
                Left Side
            </p>
        </div>
        <div class="col-12 col-md-9 col-xl-9 right">
            <p class="p-3">Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus aut, accusantium dolorum, ullam sed quod dolores neque pariatur esse facilis nemo nihil officiis, necessitatibus ab enim iusto. Reprehenderit, nobis officiis.</p>
        </div>
    </div>
</div>
    <!--  ================FOOTER========= -- -->
    <div id="footer" class="footer"></div>


    <script>
        $('.counter-count').each(function () {
        $(this).prop('Counter',0).animate({
            Counter: $(this).text()
        }, {
            duration: 3000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });
    </script>
    <!-- =========footer section start============ -->
<div class="container-fluid ftr" id="footer">
            <div class="row ft">
                <div class="col-12 col-sm-6 col-md-3 first">
                    <img src="img/logo.jpg" alt="">
                    <h1>Donate Blood and Take Real Blessing</h1>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <h1>About us</h1>
                    <p> accusantium veniam mollitia enim perferendis, repellendus fugiat porro assumenda rerum nihil voluptas tempora, reiciendis accusamus incidunt! Labore, fugit!</p>
                    <span>Phone:- +91-9068605920</span><br>
                    <span>Email-: shobhtisthakur105@gmail.com</span>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <h1>Quick Link</h1>
                    <ul>
                        <li><span>>></span><a href="">Service</a></li>
                        <li><span>>></span><a href="">About Us</a></li>
                        <li><span>>></span><a href="">New Campagin</a></li>
                        <li><span>>></span><a href="">Contact</a></li>
                    </ul>
                </div>
                <div class="col-12 col-sm-6 col-md-3">
                    <h1>service</h1>
                    <ul>
                        <li><span>>></span><a href="">Blood Donation</a></li>
                        <li><span>>></span><a href="">Health Check</a></li>
                        <li><span>>></span><a href="">Blood Bank</a></li>
                        <li><span>>></span><a href="">Donation Process</a></li>
                        <li><span>>></span><a href="">Blood Info</a></li>
                    </ul>
                </div>
            </div>
            <div class="btm-ft text-center">
                <p>Copyright 2023 Sobhit Jadoun, All Right Reserved</p>
            </div>
        </div>

<!-- ===============footer section end================
 -->

</body>

</html>